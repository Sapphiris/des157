(function(){
    "use strict";
})();

var myForm = document.querySelector("#myForm");

var text1 = document.querySelector("#text1");
var text2 = document.querySelector("#text2");
var text3 = document.querySelector("#text3");
var text4 = document.querySelector("#text4");
var text5 = document.querySelector("#text5");
var text6 = document.querySelector("#text6");
var text7 = document.querySelector("#text7");
var text8 = document.querySelector("#text8");
var text9 = document.querySelector("#text9");
var text10 = document.querySelector("#text10");

myForm.addEventListener("submit", function(event){
    event.preventDefault();
    var fName = document.querySelector("#fName").value;
    var mName = document.querySelector("#mName").value;
    var day = document.querySelector("#day").value;
    var food = document.querySelector("#food").value;
    var timeOfDay = document.querySelector("#timeOfDay").value;
    var location = document.querySelector("#location").value;

    var dialogue1 = `${mName}, I... I like you!`;
    var dialogue2 = `I've liked you for all this time!`;
    var dialogue3 = `${fName}, I.. I like you too!`;
    var dialogue4 = `Our feelings are mutual???`;
    var dialogue5 = `So... Are you free this coming ${day}?`;
    var dialogue6 = `We can grab some ${food} togeth--`;
    var dialogue7 = `${timeOfDay}!!! Meet me at ${location}!!!`;
    var dialogue8 = `And don't be late!!`;
    var dialogue9 = `Ok bye! ♥`;
    var dialogue10 = `Ehh?`;

    text1.innerHTML = dialogue1;
    text2.innerHTML = dialogue2;
    text3.innerHTML = dialogue3;
    text4.innerHTML = dialogue4;
    text5.innerHTML = dialogue5;
    text6.innerHTML = dialogue6;
    text7.innerHTML = dialogue7;
    text8.innerHTML = dialogue8;
    text9.innerHTML = dialogue9;
    text10.innerHTML = dialogue10;

    var formData = document.querySelectorAll("input[type=text]");
    for(eachField of formData){
        eachField.value = "";
    }
});